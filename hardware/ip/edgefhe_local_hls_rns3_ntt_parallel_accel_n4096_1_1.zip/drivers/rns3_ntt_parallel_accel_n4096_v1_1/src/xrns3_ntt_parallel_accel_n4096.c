// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xrns3_ntt_parallel_accel_n4096.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XRns3_ntt_parallel_accel_n4096_CfgInitialize(XRns3_ntt_parallel_accel_n4096 *InstancePtr, XRns3_ntt_parallel_accel_n4096_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XRns3_ntt_parallel_accel_n4096_Start(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRns3_ntt_parallel_accel_n4096_ReadReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_AP_CTRL) & 0x80;
    XRns3_ntt_parallel_accel_n4096_WriteReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XRns3_ntt_parallel_accel_n4096_IsDone(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRns3_ntt_parallel_accel_n4096_ReadReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XRns3_ntt_parallel_accel_n4096_IsIdle(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRns3_ntt_parallel_accel_n4096_ReadReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XRns3_ntt_parallel_accel_n4096_IsReady(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRns3_ntt_parallel_accel_n4096_ReadReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XRns3_ntt_parallel_accel_n4096_EnableAutoRestart(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRns3_ntt_parallel_accel_n4096_WriteReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XRns3_ntt_parallel_accel_n4096_DisableAutoRestart(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRns3_ntt_parallel_accel_n4096_WriteReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_AP_CTRL, 0);
}

void XRns3_ntt_parallel_accel_n4096_Set_operation(XRns3_ntt_parallel_accel_n4096 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRns3_ntt_parallel_accel_n4096_WriteReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_OPERATION_DATA, Data);
}

u32 XRns3_ntt_parallel_accel_n4096_Get_operation(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRns3_ntt_parallel_accel_n4096_ReadReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_OPERATION_DATA);
    return Data;
}

void XRns3_ntt_parallel_accel_n4096_InterruptGlobalEnable(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRns3_ntt_parallel_accel_n4096_WriteReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_GIE, 1);
}

void XRns3_ntt_parallel_accel_n4096_InterruptGlobalDisable(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRns3_ntt_parallel_accel_n4096_WriteReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_GIE, 0);
}

void XRns3_ntt_parallel_accel_n4096_InterruptEnable(XRns3_ntt_parallel_accel_n4096 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRns3_ntt_parallel_accel_n4096_ReadReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_IER);
    XRns3_ntt_parallel_accel_n4096_WriteReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_IER, Register | Mask);
}

void XRns3_ntt_parallel_accel_n4096_InterruptDisable(XRns3_ntt_parallel_accel_n4096 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRns3_ntt_parallel_accel_n4096_ReadReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_IER);
    XRns3_ntt_parallel_accel_n4096_WriteReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_IER, Register & (~Mask));
}

void XRns3_ntt_parallel_accel_n4096_InterruptClear(XRns3_ntt_parallel_accel_n4096 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    //XRns3_ntt_parallel_accel_n4096_WriteReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_ISR, Mask);
}

u32 XRns3_ntt_parallel_accel_n4096_InterruptGetEnabled(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRns3_ntt_parallel_accel_n4096_ReadReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_IER);
}

u32 XRns3_ntt_parallel_accel_n4096_InterruptGetStatus(XRns3_ntt_parallel_accel_n4096 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    // Current Interrupt Clear Behavior is Clear on Read(COR).
    return XRns3_ntt_parallel_accel_n4096_ReadReg(InstancePtr->Control_BaseAddress, XRNS3_NTT_PARALLEL_ACCEL_N4096_CONTROL_ADDR_ISR);
}

