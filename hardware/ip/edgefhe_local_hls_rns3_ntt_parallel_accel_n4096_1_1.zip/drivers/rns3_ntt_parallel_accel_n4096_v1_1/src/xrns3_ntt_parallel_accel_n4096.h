// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XRNS3_NTT_PARALLEL_ACCEL_N4096_H
#define XRNS3_NTT_PARALLEL_ACCEL_N4096_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xrns3_ntt_parallel_accel_n4096_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XRns3_ntt_parallel_accel_n4096_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XRns3_ntt_parallel_accel_n4096;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XRns3_ntt_parallel_accel_n4096_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XRns3_ntt_parallel_accel_n4096_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XRns3_ntt_parallel_accel_n4096_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XRns3_ntt_parallel_accel_n4096_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XRns3_ntt_parallel_accel_n4096_Initialize(XRns3_ntt_parallel_accel_n4096 *InstancePtr, u16 DeviceId);
XRns3_ntt_parallel_accel_n4096_Config* XRns3_ntt_parallel_accel_n4096_LookupConfig(u16 DeviceId);
int XRns3_ntt_parallel_accel_n4096_CfgInitialize(XRns3_ntt_parallel_accel_n4096 *InstancePtr, XRns3_ntt_parallel_accel_n4096_Config *ConfigPtr);
#else
int XRns3_ntt_parallel_accel_n4096_Initialize(XRns3_ntt_parallel_accel_n4096 *InstancePtr, const char* InstanceName);
int XRns3_ntt_parallel_accel_n4096_Release(XRns3_ntt_parallel_accel_n4096 *InstancePtr);
#endif

void XRns3_ntt_parallel_accel_n4096_Start(XRns3_ntt_parallel_accel_n4096 *InstancePtr);
u32 XRns3_ntt_parallel_accel_n4096_IsDone(XRns3_ntt_parallel_accel_n4096 *InstancePtr);
u32 XRns3_ntt_parallel_accel_n4096_IsIdle(XRns3_ntt_parallel_accel_n4096 *InstancePtr);
u32 XRns3_ntt_parallel_accel_n4096_IsReady(XRns3_ntt_parallel_accel_n4096 *InstancePtr);
void XRns3_ntt_parallel_accel_n4096_EnableAutoRestart(XRns3_ntt_parallel_accel_n4096 *InstancePtr);
void XRns3_ntt_parallel_accel_n4096_DisableAutoRestart(XRns3_ntt_parallel_accel_n4096 *InstancePtr);

void XRns3_ntt_parallel_accel_n4096_Set_operation(XRns3_ntt_parallel_accel_n4096 *InstancePtr, u32 Data);
u32 XRns3_ntt_parallel_accel_n4096_Get_operation(XRns3_ntt_parallel_accel_n4096 *InstancePtr);

void XRns3_ntt_parallel_accel_n4096_InterruptGlobalEnable(XRns3_ntt_parallel_accel_n4096 *InstancePtr);
void XRns3_ntt_parallel_accel_n4096_InterruptGlobalDisable(XRns3_ntt_parallel_accel_n4096 *InstancePtr);
void XRns3_ntt_parallel_accel_n4096_InterruptEnable(XRns3_ntt_parallel_accel_n4096 *InstancePtr, u32 Mask);
void XRns3_ntt_parallel_accel_n4096_InterruptDisable(XRns3_ntt_parallel_accel_n4096 *InstancePtr, u32 Mask);
void XRns3_ntt_parallel_accel_n4096_InterruptClear(XRns3_ntt_parallel_accel_n4096 *InstancePtr, u32 Mask);
u32 XRns3_ntt_parallel_accel_n4096_InterruptGetEnabled(XRns3_ntt_parallel_accel_n4096 *InstancePtr);
u32 XRns3_ntt_parallel_accel_n4096_InterruptGetStatus(XRns3_ntt_parallel_accel_n4096 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
