-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
-- Tool Version Limit: 2022.04
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity rns3_ntt_parallel_accel_n4096_generate_stage_twiddles_RNS_STAGE_ROOT_INV_MONT_V_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 30; 
             AddressWidth     : integer := 6; 
             AddressRange    : integer := 36
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of rns3_ntt_parallel_accel_n4096_generate_stage_twiddles_RNS_STAGE_ROOT_INV_MONT_V_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "101001100000000000000000000101", 1 => "010010010010111010101101110111", 
    2 => "010010010101010101100010100110", 3 => "111000100001110000100101010010", 
    4 => "110110100010111100010010110110", 5 => "001011001101010101110111101001", 
    6 => "010010010100011001001101100110", 7 => "100111011010111101011000101101", 
    8 => "110011001101111100001111101010", 9 => "011010101000111001011000001111", 
    10 => "000101111100100001101100001000", 11 => "100011010101111100010011111111", 
    12 => "101011011000000000000000000101", 13 => "110111111011101011001011011010", 
    14 => "001110100011010011011011011010", 15 => "001110010011011000101010001100", 
    16 => "101101110011001111111010110000", 17 => "000000101010010111110010010001", 
    18 => "000110010011101011011101001001", 19 => "000101000101100111100001110110", 
    20 => "011011100110110011100110110100", 21 => "110011000001000100001011101110", 
    22 => "011011011111111100011101101100", 23 => "000010000100110000110101110111", 
    24 => "011000000000000000000000001010", 25 => "000101010100000011011110011100", 
    26 => "000101011111011100010010010011", 27 => "010000110011010001001001100011", 
    28 => "001000000111100110010101011000", 29 => "001100001001110011010001011101", 
    30 => "000010001000000011000000100000", 31 => "000110010111100011101110101001", 
    32 => "011010000101010100111001101110", 33 => "010101111111111011101010011100", 
    34 => "001001011100010011110111011101", 35 => "010111001101111010001011010000" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

