-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
-- Tool Version Limit: 2022.04
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity rns3_ntt_parallel_accel_n4096_generate_stage_twiddles_RNS_STAGE_ROOT_FWD_MONT_V_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 30; 
             AddressWidth     : integer := 6; 
             AddressRange    : integer := 36
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of rns3_ntt_parallel_accel_n4096_generate_stage_twiddles_RNS_STAGE_ROOT_FWD_MONT_V_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "101001100000000000000000000101", 1 => "101001001101000101010010001010", 
    2 => "110100111101110000001101011111", 3 => "000011001111111110001011110101", 
    4 => "100001111000010011011100110100", 5 => "001101110110010000111111110011", 
    6 => "000010000001111001011101010011", 7 => "000000010011101001111011110011", 
    8 => "101100011010111000101001000010", 9 => "110001001010110101111100010001", 
    10 => "110000101011101111000100011011", 11 => "101110000111000000100110101011", 
    12 => "101011011000000000000000000101", 13 => "000011111100010100110100100111", 
    14 => "000111011110100011011011111101", 15 => "101000101000001110010111111010", 
    16 => "110011001111000101100000111101", 17 => "101011101011011100011001001101", 
    18 => "101000000010110001101000010000", 19 => "110100100011011000011100110101", 
    20 => "010011111000101100110101010000", 21 => "011000110001010010101010111111", 
    22 => "011011111111111110001101110000", 23 => "110011010000100011001010001100", 
    24 => "011000000000000000000000001010", 25 => "010110101011111100100001100101", 
    26 => "001101010100011000000100000011", 27 => "000011110100111111100001101101", 
    28 => "010010101001001110000011101010", 29 => "010101000110000001101011001110", 
    30 => "011000111010101011111111100000", 31 => "000111011101100100100001010000", 
    32 => "000110010010101110000111010011", 33 => "010100000001011011100000001100", 
    34 => "010101110101101001001000000100", 35 => "010110110011100100010101100001" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

