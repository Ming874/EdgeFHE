// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
`timescale 1 ns / 1 ps
module rns3_ntt_parallel_accel_n4096_generate_power_cache_RNS_MONTGOMERY_NEG_INV_V13_ROM_AUTO_1R (
address0, ce0, q0, reset,clk);

parameter DataWidth = 30;
parameter AddressWidth = 2;
parameter AddressRange = 3;

input[AddressWidth-1:0] address0;
input ce0;
output reg[DataWidth-1:0] q0;
input reset;
input clk;

reg [DataWidth-1:0] ram[0:AddressRange-1];

initial begin
    $readmemh("./rns3_ntt_parallel_accel_n4096_generate_power_cache_RNS_MONTGOMERY_NEG_INV_V13_ROM_AUTO_1R.dat", ram);
end



always @(posedge clk)  
begin 
    if (ce0) 
    begin
        q0 <= ram[address0];
    end
end



endmodule

